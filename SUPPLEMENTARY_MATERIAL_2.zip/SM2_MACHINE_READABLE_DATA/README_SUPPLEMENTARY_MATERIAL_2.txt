Supplementary Material 2: machine-readable data (CSV, UTF-8, comma-separated)

Working title (provisional): Programme-Dependent Bias and Uncertainty in Mass-Loss-Based
  Estimates of Retained Ultimate Strength of Artificially Corroded Reinforcing Steel
Author: Faisal M. A. Alzahrani, Department of Mechanical Engineering, Yanbu Industrial College,
  Royal Commission for Jubail and Yanbu, P.O. Box 30436, Yanbu Al-Sinaiyah 41912, Saudi Arabia
Corresponding author: zahranifai@rcjy.edu.sa

Numbering: main-text Tables 1-2 and Figs. 1-4 and supplementary Tables S1-S14 follow the redesigned
author-review manuscript (November 2026).

Folders
  tables_main/            Table 1 (programmes) and Table 2 (primary held-out results, M0-M2; every value taken
                          from the frozen supplementary tables and N2 outputs)
  tables_supplementary/   Tables S1-S11, S13 and S14 (S14 = per-programme held-out performance; S2 and S8 provided
                          only here). Table S12 (model and validation-design definitions) is in Supplementary Material 1 only.
  figure_data/            The plotted values of main-text Figs. 2-4 (Fig. 4: from TABLE_S4 and
                          programme_results/random_vs_lopo_per_programme.csv) (selected and sorted from frozen outputs; no
                          recomputation)
  n2_uncertainty/         Full-precision programme-level uncertainty outputs (summarised in Table 2, Fig. 2 and Tables S10-S11)
                          and programme-level detail (S1 bias and S6 within-programme SD per programme and model)
  predictions/            Held-out predictions for all 707 specimens: LOPO (all models, with interval
                          limits and novelty measures), record-random diagnostic, and LOPO fold assignments
  programme_results/      Per-programme and overall LOPO metrics, interval coverage by programme,
                          random-vs-LOPO comparison by programme
  derived_data/           The 707-test impressed-current analysis cohort (with source row numbers)
                          and programme coverage
  metadata/               Corrosion-protocol attributes per programme as recorded in the source database;
                          the current density of Imperatore et al. (2017) is a compiler-imputed value
                          (see the database_comment column)
  DATA_DICTIONARY.csv     Column descriptions for every file

Conventions: error = predicted - observed retained strength (percentage points); positive = non-conservative.
For fitted models (M1-M3), each programme's held-out predictions come from a different outer-fold model,
so the dispersion of programme bias includes variation among fitted models.

Source data and licence: Matthews, B., Palermo, A., Scott, A. (2024) Monotonic Tensile Testing of Corroded
Reinforcing Steel Bars Database (Version 2). Zenodo. https://doi.org/10.5281/zenodo.12578868. CC BY 4.0.
Changes: impressed-current subset selection, column renaming, computed predictions and summaries; measured
values unchanged. The derived files are provided under CC BY 4.0 with attribution to this work and the source.
